After Installing Application Run it.
Press ENTER.
Connect the Arduino to Phone.
Place Your Hand on Pulse Sensor.
See the Results on Your Phone.